# youcode-restaurent
## Project context
### Restaurant Youcode vient d'ouvrir ses portes. il a besoin d'un système de gestion de son restaurant en ligne permettant de répondre aux histoires suivants :

- Autant que utilisateur (Apprenant / Staff ), je peux me connecter afin de voir le menu de la semaine.
- Autant que utilisateur (Apprenant / Staff ), je peux séléctionner mon plat du jour.
- Autant que utilisateur (Apprenant / Staff ), je peux laisser un feedback par rapport la qualité du plat consomé.
- Autant que Staff restaurant, je peux me connecter afin de gérer les plats et les commandes.
- Autant que Staff restaurant, je peux ajouter Ajouter/Modifier/Supprimer les plats afin de livrer les plats de la semaine.
- Autant que Staff restaurant, je peux voir les réservations des plats par jour au but de les préparer avec des quantités convenable.
- Autant que Staff restaurant, je peux voir les statistique de satisfaction.
- Autant que Administrateur, je peux me connecter afin de gérer les utilisateurs (CRUD).
- Autant que Administrateur, je peux gérer les droits de sélection du plat du jour afin de pouvoir enlever ce droit aux utilisateur absent.
